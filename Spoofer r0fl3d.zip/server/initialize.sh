rm -r model_dir
rm -r pretrain